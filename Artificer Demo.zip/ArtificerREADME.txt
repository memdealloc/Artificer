ARTIFICER DEMO
by Smart_Alloc

------------------------------------------

Controls:
Arrow Keys:	Move
Z:		Jump
X:		Use Sword (Can be held)
C:		Use Shuriken (Can be held)

R:		Restart Game
Q/ESC:		Quit Game

------------------------------------------

Just run around and explore, I guess
Hearts increase your max health by 1.
Every ten coins you get, your max health also increases by 1

If you collect all 40 coins and reach 10 health, you'll unlock
a new, never-before-seen weapon!